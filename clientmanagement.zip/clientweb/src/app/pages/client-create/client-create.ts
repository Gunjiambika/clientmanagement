import { Component } from '@angular/core';

@Component({
  selector: 'app-client-create',
  standalone: true,
  templateUrl: './client-create.html',
  styleUrls: ['./client-create.css']
})
export class ClientCreate {}