import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientMeetings } from './client-meetings';

describe('ClientMeetings', () => {
  let component: ClientMeetings;
  let fixture: ComponentFixture<ClientMeetings>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClientMeetings],
    }).compileComponents();

    fixture = TestBed.createComponent(ClientMeetings);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
