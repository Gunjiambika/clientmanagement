import { Component } from '@angular/core';

@Component({
  selector: 'app-client-meetings',
  standalone: true,
  templateUrl: './client-meetings.html',
  styleUrls: ['./client-meetings.css'],
})
export class ClientMeetings {}