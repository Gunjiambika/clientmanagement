import { Routes } from '@angular/router';
import { ClientCreate } from './pages/client-create/client-create';
import { ClientMeetings } from './pages/client-meetings/client-meetings';

export const routes: Routes = [
  { path: '', redirectTo: 'clients', pathMatch: 'full' },
  { path: 'clients', component: ClientCreate },
  { path: 'meetings', component: ClientMeetings }
];